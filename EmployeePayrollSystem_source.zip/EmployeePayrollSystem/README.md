# Employee Payroll System (Java OOP)

A console-based Java application that demonstrates the core Object-Oriented
Programming concepts: classes and objects, encapsulation, inheritance,
polymorphism and abstraction.

## Class overview

| Class / Interface   | Role                                                         |
|---------------------|--------------------------------------------------------------|
| `Payable`           | Interface – every payable object has gross and net pay       |
| `Employee`          | Abstract superclass (private fields, getters/setters)        |
| `FullTimeEmployee`  | Extends `Employee` – monthly salary + allowance, EPF 11%     |
| `PartTimeEmployee`  | Extends `Employee` – hourly rate x hours worked              |
| `Manager`           | Extends `FullTimeEmployee` – adds bonus and team size        |
| `PayrollSystem`     | Holds `ArrayList<Employee>` and performs payroll operations  |
| `Main`              | Menu-driven console UI using `Scanner`                       |

## How to compile and run

Requires JDK 8 or newer.

```bash
cd src
javac *.java
java Main
```

## Features

- Add full-time, part-time and manager employees
- Display all employees
- View a payslip by employee ID
- Give a salary / hourly-rate raise
- Remove an employee
- Payroll summary (total gross and net)
- Polymorphism demo (menu option 9)
- Load sample data (menu option 10) for a quick demonstration
